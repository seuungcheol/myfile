function dw(str){   //var str; var str="고양이";
    document.write(str);
}
function br(){
    document.write("<br>");
}