var animal=["개","고양이","토끼"];
dw(animal[0]);
br();
dw(animal[1]);
br();
dw(animal[2]);
br();

for (var i=0;i<3;i++){
    dw(animal[i]);
    br();
}

var animal=["말","돼지","소"];
dw(animal[0]);
br();
dw(animal[1]);
br();
dw(animal[2]);
br();

for (var j=0;j<3;j++){
    dw(animal[j]);
    br();
}