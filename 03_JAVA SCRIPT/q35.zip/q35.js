var com = [0,1,2,3,4];
dw(com[0]);
br();
dw(com[1]);
br();
dw(com[2]);
br();
dw(com[3]);
br();
dw(com[4]);
br();

for (var i=0;i<5;i++){
    dw(com[i]);
    br();
}