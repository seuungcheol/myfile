// var numbers = new Array(7);

// for(var i=0;i<numbers.length;i++){   // 배열 수 만큼 반복
//     numbers[i] = Math.floor(Math.random()*45+1);
//     dw(numbers[i]);
//     br();
// }

var com = new Array(10);

for(var i=0;i<com.length;i++){
    com[i] = Math.floor(Math.random()*45+1);
    dw(com[i]);
    br();
}

for(var s=0;s<com.length;s++){
    com[s]=Math.floor(Math.random()*45+1);
    dw(com[s]);
    br();
}