var com = new Array(6);

for(var i=0;i<com.length;i++){   // 배열 수 만큼 반복
    com[i] = Math.floor(Math.random()*45+1);
    dw(com[i]+"\n");
}
