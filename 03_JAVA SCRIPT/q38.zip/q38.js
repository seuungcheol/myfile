var myLotto = [3,10,15,25,37,45]
dw("내 번호:"+"\n"+myLotto[0]+"\n");
dw(myLotto[1]+"\n");
dw(myLotto[2]+"\n");
dw(myLotto[3]+"\n");
dw(myLotto[4]+"\n");
dw(myLotto[5]+"\n");
br();
dw("pc넘버:"+"\n");


var com = new Array(6);

for(var i=0;i<com.length;i++){   // 배열 수 만큼 반복
    com[i] = Math.floor(Math.random()*45+1);
    for(var j=0; j<i; j++){
        if(com[i]==com[j]){
            i-1;
        }dw();
    }
}