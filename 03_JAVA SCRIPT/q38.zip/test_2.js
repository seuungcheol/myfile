for(let i=0; i<6; i++){
    com[i] = Math.floor(Math.random() * 45) + 1; 
    for(let j=0; j<i; j++){
        if(com[i] == com[j]) {
            i--;
        }dw(com[i]);
    }
}