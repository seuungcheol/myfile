var me = [ 3, 10, 15, 25, 37, 45 ]; 
var com = new Array(7);

var count=0;  //일치하는 번호 수//
var result=0; //당첨 등수//

var bonusNO = com[6]; //보너스 번호//

dw("내 번호:"+ "\n" + me );
br();
dw("pc넘버:"+"\n");

// com 번호 출력, 중복 체크//
com[0] = Math.floor(Math.random()*45+1);
dw(com[0] + "\n");

while (true){
    com[1] = Math.floor(Math.random()*45+1);
    if ( com[0] == com[1]){
        continue;
    } else {
        break;
    }
}    
dw(com[1] +"\n");

while (true){
    com[2] = Math.floor(Math.random()*45+1);
    if (com[0] == com[2]){
        continue;
    } else if (com[1] == com[2]){
        continue;
    } else {
        break;
    }
}    
dw(com[2] +"\n");

while (true){
    com[3] = Math.floor(Math.random()*45+1);
    if (com[0] == com[3]){
        continue;
    } else if (com[1] == com[3]){
        continue;
    } else if (com[2] == com[3]){
        continue;
    } else {
        break;
    }
}    
dw(com[3] +"\n");

while (true){
    com[4] = Math.floor(Math.random()*45+1);
    if (com[0] == com[4]){
        continue;
    } else if (com[1] == com[4]){
        continue;
    } else if (com[2] == com[4]){
        continue;
    } else if (com[3] == com[4]){
        continue;
    } else {
        break;
    }
}    
dw(com[4] +"\n");

while (true){
    com[5] = Math.floor(Math.random()*45+1);
    if (com[0] == com[5]){
        continue;
    } else if (com[1] == com[5]){
        continue;
    } else if (com[2] == com[5]){
        continue;
    } else if (com[3] == com[5]){
        continue;
    } else if (com[4] == com[5]){
        continue;
    } else {
        break;
    }
}    
dw(com[5] +"\n");

//보너스 번호//
while (true){
    com[6] = Math.floor(Math.random()*45+1);
    if (com[0] == com[6]){
        continue;
    } else if (com[1] == com[6]){
        continue;
    } else if (com[2] == com[6]){
        continue;
    } else if (com[3] == com[6]){
        continue;
    } else if (com[4] == com[6]){
        continue;
    } else if (com[5] == com[6]){
        continue;
    } else {
        break;
    }
}    
// com 번호 출력, 중복 체크 //



// me 번호와 com 번호와의 일치하는 번호 수 //
if ( me[0] == com[0] ) {
    count++;
} else if ( me[0] == com[1] ){
    count++;
} else if ( me[0] == com[2] ){
    count++;
} else if ( me[0] == com[3] ){
    count++;
} else if ( me[0] == com[4] ){
    count++;
} else if ( me[0] == com[5] ){
    count++;
} else if ( me[0] == com[6] ){
    count++;
}

if ( me[1] == com[0] ) {
    count++;
} else if ( me[1] == com[1] ){
    count++;
} else if ( me[1] == com[2] ){
    count++;
} else if ( me[1] == com[3] ){
    count++;
} else if ( me[1] == com[4] ){
    count++;
} else if ( me[0] == com[5] ){
    count++;
} else if ( me[0] == com[6] ){
    count++;
}

if ( me[2] == com[0] ) {
    count++;
} else if ( me[2] == com[1] ){
    count++;
} else if ( me[2] == com[2] ){
    count++;
} else if ( me[2] == com[3] ){
    count++;
} else if ( me[2] == com[4] ){
    count++;
} else if ( me[2] == com[5] ){
    count++;
} else if ( me[0] == com[6] ){
    count++;
}

if ( me[3] == com[0] ) {
    count++;
} else if ( me[3] == com[1] ){
    count++;
} else if ( me[3] == com[2] ){
    count++;
} else if ( me[3] == com[3] ){
    count++;
} else if ( me[3] == com[4] ){
    count++;
} else if ( me[3] == com[5] ){
    count++;
} else if ( me[0] == com[6] ){
    count++;
}

if ( me[4] == com[0] ) {
    count++;
} else if ( me[4] == com[1] ){
    count++;
} else if ( me[4] == com[2] ){
    count++;
} else if ( me[4] == com[3] ){
    count++;
} else if ( me[4] == com[4] ){
    count++;
} else if ( me[4] == com[5] ){
    count++;
} else if ( me[0] == com[6] ){
    count++;
}

if ( me[5] == com[0] ) {
    count++;
} else if ( me[5] == com[1] ){
    count++;
} else if ( me[5] == com[2] ){
    count++;
} else if ( me[5] == com[3] ){
    count++;
} else if ( me[5] == com[4] ){
    count++;
} else if ( me[5] == com[5] ){
    count++;
} else if ( me[0] == com[6] ){
    count++;
}
// me 번호와 com 번호와의 일치하는 번호 수 //

br();
dw("일치 번호:" + count +"개");
br();
dw("보너스 번호:" + com[6]);
br();

// 당첨 등수 //
switch (count){
    case 0: dw("결과 : 낙첨!!"); break;
    case 1: dw("결과 : 낙첨!!"); break;
    case 2: dw("결과 : 낙첨!!"); break;
    case 3: dw("결과 : 5등!!"); break;
    case 4: dw("결과 : 4등!!"); break;
    case 5: dw("결과 : 3등!!"); break;
    case 6: dw("결과 : 1등!!"); break;
}

if (conut + bonusNO){
    dw("결과 : 2등!!");
}
// 당첨 등수 //


