var me = [ 1, 2, 3, 4, 5, 7 ]; 
var com = new Array(6);

var count = 0;  //일치하는 번호 수//
var result = 0; //당첨 등수//

var bonusNO = 0;//보너스 번호

dw("내 번호:"+ "\n" + me );
br();
dw("pc넘버:"+"\n");


// com 번호 출력, 중복 체크//
com[0] = Math.floor(Math.random()*7+1);
dw(com[0] + "\n");

while (true){
    com[1] = Math.floor(Math.random()*7+1);
    if ( com[0] == com[1]){
        continue;
    } else {
        break;
    }
}    
dw(com[1] +"\n");

while (true){
    com[2] = Math.floor(Math.random()*7+1);
    if (com[0] == com[2]){
        continue;
    } else if (com[1] == com[2]){
        continue;
    } else {
        break;
    }
}    
dw(com[2] +"\n");

while (true){
    com[3] = Math.floor(Math.random()*7+1);
    if (com[0] == com[3]){
        continue;
    } else if (com[1] == com[3]){
        continue;
    } else if (com[2] == com[3]){
        continue;
    } else {
        break;
    }
}    
dw(com[3] +"\n");

while (true){
    com[4] = Math.floor(Math.random()*7+1);
    if (com[0] == com[4]){
        continue;
    } else if (com[1] == com[4]){
        continue;
    } else if (com[2] == com[4]){
        continue;
    } else if (com[3] == com[4]){
        continue;
    } else {
        break;
    }
}    
dw(com[4] +"\n");

while (true){
    com[5] = Math.floor(Math.random()*7+1);
    if (com[0] == com[5]){
        continue;
    } else if (com[1] == com[5]){
        continue;
    } else if (com[2] == com[5]){
        continue;
    } else if (com[3] == com[5]){
        continue;
    } else if (com[4] == com[5]){
        continue;
    } else {
        break;
    }
}       
dw(com[5] +"\n");

while (true){
    bonusNO = Math.floor(Math.random()*7+1);
    if (com[0] == bonusNO){
        continue;
    } else if (com[1] == bonusNO){
        continue;
    } else if (com[2] == bonusNO){
        continue;
    } else if (com[3] == bonusNO){
        continue;
    } else if (com[4] == bonusNO){
        continue;
    } else if (com[5] == bonusNO){
        continue;
    } else if (com[6] == bonusNO){
        continue;
    } else {
        break;
    }
}
br();   
dw("보너스 번호: " + bonusNO);
br();
// com 번호 출력, 중복 체크 //


// me 번호와 com 번호와의 일치하는 번호 수 //
if ( me[0] == com[0] ) {
    count++;
} else if ( me[0] == com[1] ){
    count++;
} else if ( me[0] == com[2] ){
    count++;
} else if ( me[0] == com[3] ){
    count++;
} else if ( me[0] == com[4] ){
    count++;
} else if ( me[0] == com[5] ){
    count++;
}

if ( me[1] == com[0] ) {
    count++;
} else if ( me[1] == com[1] ){
    count++;
} else if ( me[1] == com[2] ){
    count++;
} else if ( me[1] == com[3] ){
    count++;
} else if ( me[1] == com[4] ){
    count++;
} else if ( me[1] == com[5] ){
    count++;
}

if ( me[2] == com[0] ) {
    count++;
} else if ( me[2] == com[1] ){
    count++;
} else if ( me[2] == com[2] ){
    count++;
} else if ( me[2] == com[3] ){
    count++;
} else if ( me[2] == com[4] ){
    count++;
} else if ( me[2] == com[5] ){
    count++;
}

if ( me[3] == com[0] ) {
    count++;
} else if ( me[3] == com[1] ){
    count++;
} else if ( me[3] == com[2] ){
    count++;
} else if ( me[3] == com[3] ){
    count++;
} else if ( me[3] == com[4] ){
    count++;
} else if ( me[3] == com[5] ){
    count++;
}

if ( me[4] == com[0] ) {
    count++;
} else if ( me[4] == com[1] ){
    count++;
} else if ( me[4] == com[2] ){
    count++;
} else if ( me[4] == com[3] ){
    count++;
} else if ( me[4] == com[4] ){
    count++;
} else if ( me[4] == com[5] ){
    count++;
}

if ( me[5] == com[0] ) {
    count++;
} else if ( me[5] == com[1] ){
    count++;
} else if ( me[5] == com[2] ){
    count++;
} else if ( me[5] == com[3] ){
    count++;
} else if ( me[5] == com[4] ){
    count++;
} else if ( me[5] == com[5] ){
    count++;
}
// me 번호와 com 번호와의 일치하는 번호 수 //

br();
dw("일치 번호:" + count +"개");
br();

// 당첨 등수 //
var rank = "";
switch (count){
    case 3:rank = "5등 입니다."; break;
    case 4:rank = "4등 입니다."; break;
    case 5:rank = "3등 입니다.";
        for (var i = 0; i < 6; i++){
            if(me[i] == bonusNO){
                rank = "2등 입니다.";

            }
        }break;        
    case 6:rank = "1등 입니다."; break;
    default:rank = "꽝 입니다."; break;
}
dw("결과 :" + rank);
// 당첨 등수 //


