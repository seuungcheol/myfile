function a(){
    return 100;
}


function b(){
    return 200;
}

function c(x, y){
    var z = x + y ;
    return z;
    // return x + y ;
}

var s = c( a() , b() );
dw(s);