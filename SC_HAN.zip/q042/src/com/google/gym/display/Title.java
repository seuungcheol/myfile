package com.google.gym.display;

public class Title {
	public static final String TITLE = "~~헬스장 관리 프로그램 만들기~~";
	

}

