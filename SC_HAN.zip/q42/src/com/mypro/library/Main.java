package com.mypro.library;

import com.mypro.library.member.Member;
import java.util.ArrayList;
import java.util.Scanner;

import com.mypro.library.Title.Title;

public class Main {
	public static void main(String[] args) {
		System.out.println(Title.TITLE);
		
		ArrayList<Member> members = new ArrayList<Member>();
		
		members.add(new Member("직장", "안부장", "010", "남자"));
		members.add(new Member("직장", "이한성", "010", "남자"));
		members.add(new Member("친구", "정지성", "010", "남자"));
		members.add(new Member("가족", "한승배", "010", "남자"));
		
		Scanner sc = new Scanner(System.in);
		
		boolean isNotEnd = true;
		while(isNotEnd) {
			
			String cmd = sc.next();
			switch(cmd) {
			case "1":
				System.out.println("**등록된 연락처**");
				for(Member m:members) {
					m.info();
				}
				break;
				
			case "2":				
				System.out.println("**검색**");
				String seachGroup = sc.next();
				while(isNotEnd){
				int searchIndex = -1;
				
				
			
				for(int i=0;i<members.size();i++) {
					if(members.get(i).getGroup().equals(seachGroup)) {
						searchIndex = i;
						break;
					}
				}
				
				if(searchIndex == -1) {
					System.out.println("회원 정보가 음.");
				} else {
					Member m = members.get(searchIndex);
					m.info();
				}
			}
				
				break;
				
			case "3":
				System.out.println("**신규 등록**");
				System.out.print("그룹 :");
				String group = sc.next();
				System.out.print("신규 이름 :");
				String name = sc.next();
				System.out.print("신규 연락처 :");
				String tel = sc.next();
				System.out.print("성별 :");
				String sex = sc.next();
				members.add(new Member(group,name,tel,sex));
				Member m = new Member(group,name,tel,sex);
				System.out.println("!!등록 완료!!");
				m.info();
				break;
				
			case "4":
				System.out.println("삭제");
				break;
				
			case "5":
				System.out.println("수정");
				break;
				
			case "e":
				System.out.println("프로그램 종료");
				isNotEnd = false;
				break;
				default:System.out.println("잘못 입력 되었습니다.다시 입력 바랍니다.");
			}
		}
		
	}
}
