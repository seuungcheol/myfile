package com.mypro.library.Title;

public class Title {
	public static final String TITLE = "~~~~~전화 번호부~~~~~"+"\n"+
						"명령어 1.전체 연락처 2.연락처 검색 3.신규 등록 4.연락처 삭제 5.정보 수정 e.종료";

}
