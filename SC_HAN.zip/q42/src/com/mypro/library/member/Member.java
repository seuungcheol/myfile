package com.mypro.library.member;

public class Member {
	//회원 정보 목록
	private	String group;
	private String name;
	private String tel;
	private String sex;
	
	public Member(String group, String name, String tel, String sex) {
		this.group = group;
		this.name = name;
		this.tel = tel;
		this.sex = sex;
	}

	public String getGroup() {
		return group;
	}

	public void setGrup(String group) {
		this.group = group;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	//회원 정보 출력
	public void info() {
		System.out.println("그룹:" + group + " 이름:" + name + " 전화번호:" + tel + " 성별:" + sex);
	}

}
