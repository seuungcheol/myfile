package com.han.shop;

public class Main {
	public static void main(String[] args) {
		Shop shop = new Shop();
		shop.proc();
	}
}
