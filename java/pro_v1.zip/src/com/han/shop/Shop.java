package com.han.shop;

import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Member;
import com.han.shop.proc.MenuMemberDel;
import com.han.shop.proc.MenuMemberEdit;
import com.han.shop.proc.MenuMemberList;
import com.han.shop.proc.MenuMemberReg;
import com.han.shop.title.Title;

public class Shop {
	public static final String VERSION = "v0.1.0";
		
	void proc() {
		
		ArrayList<Member> members = new ArrayList<Member>();
		
		members.add(new Member(1,"한승철", "010-0000", "남자"));
		members.add(new Member(3,"조성률", "010-1111", "남자"));
		members.add(new Member(5,"정지성", "010-2222", "남자"));
		members.add(new Member(7,"박찬신", "010-3333", "남자"));
		
		System.out.println(Title.TITLE);
		
		Scanner sc = new Scanner(System.in);
		boolean isNotEnd = true;
		while(isNotEnd) {
			System.out.println("전체 메뉴: 1.신규 등록 2.전체 회원 3.회원 삭제 4.회원 정보 수정 e.종료");
			String cmd = sc.next();
			switch(cmd) {
			case "1":
				//신규 등록
				MenuMemberReg menuMemberReg = new MenuMemberReg();
				menuMemberReg.proc(members);
				break;
			case "2":
				//전체 회원 출력
				MenuMemberList menuMemberList = new MenuMemberList();
				menuMemberList.proc(members);
				break;
			case "3": 
				//회원 삭제
				MenuMemberDel menuMemberDel = new MenuMemberDel();
				menuMemberDel.proc(members);
				break;
			case "4": 
				//회원 정보 수정
				MenuMemberEdit menuMemberEdit = new MenuMemberEdit();
				menuMemberEdit.proc(members);
				break;
			case "e": break;
			//프로그램 종료
			default:System.out.println("잘못 입력 되었습니다.");break;
			}
			
		}
	}

}
