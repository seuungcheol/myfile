package com.han.shop.proc;

import java.util.ArrayList;

import com.han.shop.data.Member;

public class MenuMemberList {
	public void proc(ArrayList<Member> members){
		for(Member m:members) {
			m.info();
		}
	}
	

}
