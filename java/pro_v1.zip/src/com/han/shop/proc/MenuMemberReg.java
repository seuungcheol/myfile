package com.han.shop.proc;


import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Member;

public class MenuMemberReg {
	
	public void proc(ArrayList<Member> members) {
		Scanner sc = new Scanner(System.in);
		System.out.println("***신규 회원 등록***");
		String name;
		String tel;
		String sex;
		System.out.print("이름(x:취소):");
		name = sc.next();
		if(name.equals("x")) {
			System.out.println("입력 취소");
			return;
		}
		System.out.print("연락처(x:취소):");
		tel = sc.next();
		if(tel.equals("x")) {
			System.out.println("입력 취소");
			return;
		}
		System.out.print("성별(x:취소):");
		sex = sc.next();
		if(sex.equals("x")) {
			System.out.println("입력 취소");
			return;
		}
		System.out.println("회원 정보가 추가 완료");
		int newNum = getLastNum(members);	//기존 회원 중 마지막 번호 찾기
		newNum++;	//회원번호 생성
		System.out.println("신규 회원 번호 생성:"+newNum);
		members.add(new Member(newNum, name,tel,sex));		
	}
	private int getLastNum(ArrayList<Member> members) {
		int lastNum = -1;
		int tempNum = -1;
		for(int i=0;i<members.size();i++) {
			tempNum = members.get(i).getNum();
			if(lastNum < tempNum) {
				lastNum = tempNum;
			}
		}
		return lastNum;
		
	}
}
