package com.han.shop.title;

import com.han.shop.Shop;

public class Title {
	public static final String TITLE = "***My Shop 회원 관리 프로그램"+Shop.VERSION +"***";

}
