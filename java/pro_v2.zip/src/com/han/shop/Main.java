package com.han.shop;

public class Main {
	public static void main(String[] args) {
		manager shop = new manager();
		shop.proc();
	}
}
