package com.han.shop.data;

public class Inven {
	private Integer num;
	private String name;
	private int count;
	private double price;
	
	public Inven(Integer num, String name, int count, double price) {
		this.num = num;
		this.name = name;
		this.count = count;
		this.price = price;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	public int getPrice() {
		return count;
	}
	
	public void setPrice(int price) {
		this.count = count;
	}
	public void info() {
		System.out.println("제품코드:" + num + "||제품명:" + name + " 재고량:" + count + " 단가:￦" + price);
	}
}
