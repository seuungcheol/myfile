package com.han.shop;

import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Inven;
import com.han.shop.data.Member;
import com.han.shop.proc.MenuInvenDel;
import com.han.shop.proc.MenuInvenIn;
import com.han.shop.proc.MenuInvenList;
import com.han.shop.proc.MenuInvenOut;
import com.han.shop.proc.MenuInvenReg;
import com.han.shop.proc.MenuMemberDel;
import com.han.shop.proc.MenuMemberEdit;
import com.han.shop.proc.MenuMemberList;
import com.han.shop.proc.MenuMemberReg;
import com.han.shop.title.Title;

public class manager {
	public static final String VERSION = "v0.2.0";
		
	void proc() {
		
		//사원 정보
		ArrayList<Member> members = new ArrayList<Member>();
		
		members.add(new Member(1,"한승철", "010-0000", "남자"));
		members.add(new Member(3,"조성률", "010-1111", "남자"));
		members.add(new Member(5,"정지성", "010-2222", "남자"));
		members.add(new Member(7,"박찬신", "010-3333", "남자"));
		
		//재고 정보
		ArrayList<Inven> inven = new ArrayList<Inven>();
		
		inven.add(new Inven(1001,"Stopper", 100, 1500));
		inven.add(new Inven(1002,"Guide", 200, 1200));
		inven.add(new Inven(1003,"Bolt", 500, 100));
		inven.add(new Inven(1004,"Rail", 300, 3000));
		
		System.out.println(Title.TITLE);
		
		Scanner sc = new Scanner(System.in);
		boolean isNotEnd = true;
		while(isNotEnd) {
			System.out.println("전체 메뉴: \n 1.사원 등록 2.사원 정보 3.사원 삭제 4.사원 정보 수정 \n a.재고 보유량 b.제품 신규 등록 c.입고 등록 d.출고 등록 \n o.프로그램종료");
			String cmd = sc.next();
			switch(cmd) {
			case "1":
				//신규 등록
				MenuMemberReg menuMemberReg = new MenuMemberReg();
				menuMemberReg.proc(members);
				break;
			case "2":
				//전체 회원 출력
				MenuMemberList menuMemberList = new MenuMemberList();
				menuMemberList.proc(members);
				break;
			case "3": 
				//회원 삭제
				MenuMemberDel menuMemberDel = new MenuMemberDel();
				menuMemberDel.proc(members);
				break;
			case "4": 
				//회원 정보 수정
				MenuMemberEdit menuMemberEdit = new MenuMemberEdit();
				menuMemberEdit.proc(members);
				break;
			case "a":
				//재고량
				MenuInvenList menuInvenList = new MenuInvenList();
				menuInvenList.proc(inven);
				break;
			case "b":
				//제품 신규 등록
				MenuInvenReg menuInvenReg = new MenuInvenReg();
				menuInvenReg.proc(inven);
				break;
			case "c":
				//입고처리
				MenuInvenIn menuInvenIn = new MenuInvenIn();
				menuInvenIn.proc(inven);
				break;
			case "d":
				//출고처리
				MenuInvenOut menuInvenOut = new MenuInvenOut();
				menuInvenOut.proc(inven);
				break;
			case "e":
				//제품삭제
				MenuInvenDel menuInvenDel = new MenuInvenDel();
				menuInvenDel.proc(inven);
				break;
			case "o": break;
			//프로그램 종료
			default:System.out.println("잘못 입력 되었습니다.");break;
			}
			
		}
	}

}
