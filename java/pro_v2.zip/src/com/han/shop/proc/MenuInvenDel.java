package com.han.shop.proc;

import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Inven;

public class MenuInvenDel {
	public void proc (ArrayList<Inven> inven) {
		System.out.println("제품 코드 입력: (x:취소)");
		Scanner sc = new Scanner(System.in);
		String delNum = sc.next();
		if("x".equals(delNum)) {
			System.out.println("***입력 취소***");
			return;
		}
		int delIndex = -1;
		
		//검색
		for(int i=0;i<inven.size();i++) {
			if(inven.get(i).getNum() == Integer.parseInt(delNum)) {
				delIndex = i;
				break;
			}
		}				
		
		if(delIndex == -1) {
			System.out.println("***없는 코드 입니다.***");
		} else {
			inven.remove(delIndex);	// 삭제
			System.out.println("***"+ delNum + "번 제품 삭제완료.***");
		}	
	}

}
