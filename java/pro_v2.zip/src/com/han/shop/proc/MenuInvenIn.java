package com.han.shop.proc;

import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Inven;

public class MenuInvenIn {
	
	public void proc (ArrayList<Inven> inven) {
		System.out.println("***입고 등록***");
		System.out.println("제품 코드 입력(x:취소):");
		Scanner sc = new Scanner(System.in);
		String searchNum = sc.next();
		if("x".equals(searchNum)) {
			System.out.println("***입력 취소***");
			return;
		}
		int searchIndex = -1;
		//검색
		for(int i=0;i<inven.size();i++) {
			if(inven.get(i).getNum() == Integer.parseInt(searchNum)) {
				searchIndex = i;
				break;
			}
		}
		//입고 수량 입력
		if(searchIndex == -1) {
			System.out.println("***" + searchNum + " 코드정보 없음.***");
		} else {	////수량 입력	
			Inven i = inven.get(searchIndex);
			i.info();
			System.out.println("입고 수량 입력:");
			String stCount = sc.next();
			int count = i.getCount();
			i.setCount(count + Integer.parseInt(stCount));
			i.info();
			System.out.println("***입고 입력 완료***");
		}
		
			
	}

}

//TODO List
//-입고 등록 하기
//
//품번 검색 
//수량 입력
//입고 수량 입력
//재고량 + 입고량
//재고량 출력