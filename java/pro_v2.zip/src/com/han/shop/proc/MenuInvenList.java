package com.han.shop.proc;

import java.util.ArrayList;

import com.han.shop.data.Inven;

public class MenuInvenList {
	public void proc(ArrayList<Inven> inven){
		System.out.println("**********창 고 재 고 현 황***********");
		for(Inven i:inven) {
			i.info();
		}
		System.out.println("***********************************");
	}
}

