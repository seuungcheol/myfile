package com.han.shop.proc;

import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Inven;

public class MenuInvenReg {
	
	public void proc(ArrayList<Inven> inven) {
		Scanner sc = new Scanner(System.in);
		System.out.println("***신규 제품 등록***");
		String name;
		
		System.out.println("제품명(x:취소):");
		name = sc.next();
		if("x".equals(name)) {
			System.out.println("***입력 취소***");
			return;
		}
		System.out.println("수량(x:취소):");
		String inCount = sc.next();
		if("x".equals(inCount)) {
			System.out.println("***입력 취소***");
			return;
		}
		System.out.println("단가(x:취소):");
		String inPrice = sc.next();
		if("x".equals(inPrice)) {
			System.out.println("***입력 취소***");
			return;
		}
		//문자열 숫자로 변환 String >> int
		double price = Integer.valueOf(inPrice).intValue();
		int count = Integer.valueOf(inCount).intValue();
		
		int newNum = getLastNum(inven);	//신제품 코드 생성
		newNum++;	//제품 코드 생성
		System.out.println("제품 코드:"+newNum);
		System.out.println("***신제품 등록 완료.***");
		inven.add(new Inven(newNum, name,count,price));	
	}
	private int getLastNum(ArrayList<Inven> inven) {
		int lastNum = -1;
		int tempNum = -1;
		for(int i=0;i<inven.size();i++) {
			tempNum = inven.get(i).getNum();
			if(lastNum < tempNum) {
				lastNum = tempNum;
			}
		}
		return lastNum;
	}
}