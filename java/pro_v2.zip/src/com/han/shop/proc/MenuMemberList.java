package com.han.shop.proc;

import java.util.ArrayList;

import com.han.shop.data.Member;

public class MenuMemberList {
	public void proc(ArrayList<Member> members){
		System.out.println("***************사  원  정  보*****************");
		for(Member m:members) {
			m.info();
		}
		System.out.println("********************************************");
	}
	

}
