package com.han.shop;

public class Main {
	public static void main(String[] args) {
		Manager shop = new Manager();
		shop.proc();
	}
}
