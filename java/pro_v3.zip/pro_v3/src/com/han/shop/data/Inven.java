package com.han.shop.data;

import java.util.HashMap;

public class Inven {
	private Integer typeCode;
	private String type;
	private String name;
	private	Integer nameCode;
	private int count;
	private double buy;
	private double sell;
	
	public Inven (Integer typeCode, String Type, String name, Integer nameCode, int count, double buy, double sell) {
		this.typeCode = typeCode;
		this.type = Type;
		this.name = name;
		this.nameCode = nameCode;
		this.count = count;
		this.buy = buy;
		this.sell = sell;
	}

	public Integer getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(Integer typeCode) {
		this.typeCode = typeCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getNameCode() {
		return nameCode;
	}

	public void setNameCode(Integer nameCode) {
		this.nameCode = nameCode;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public double getBuy() {
		return buy;
	}

	public void setBuy(double buy) {
		this.buy = buy;
	}

	public double getSell() {
		return sell;
	}

	public void setSell(double sell) {
		this.sell = sell;
	}

	public void info() {
		System.out.println("제품군:" + type + "|(" + nameCode + ")|"+"규격:" + name + " 재고량:" + count + " 구매가:￦" + buy + " 판매가:￦" + sell);
	}
}
