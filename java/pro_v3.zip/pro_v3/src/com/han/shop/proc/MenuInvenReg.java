package com.han.shop.proc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.han.shop.data.Inven;

public class MenuInvenReg {
	
	
	public void proc(ArrayList<Inven> inven) {
		Scanner sc = new Scanner(System.in);
		System.out.println("***신규 제품 등록***");
		
		System.out.println("타입 코드(1:Stopper 2:Guide 3:Bolt 0:취소):");
		Integer typeCode = sc.nextInt();
		if("x".equals(typeCode)) {
			System.out.println("***입력 취소***");
			return;
		}
		
		System.out.println("제품 타입(1:Stopper, 2:Guide, 3:Bolt, x:취소):");
		String type = sc.next();
		if("x".equals(type)) {
			System.out.println("***입력 취소***");
			return;
		}
		
		System.out.println("제품명(x:취소):");
		String name = sc.next();
		if("x".equals(name)) {
			System.out.println("***입력 취소***");
			return;
		}
		System.out.println("수량(x:취소):");
		int count = sc.nextInt();
		if("x".equals(count)) {
			System.out.println("***입력 취소***");
			return;
		}
		System.out.println("구매가(x:취소):");
		double buy = sc.nextInt();
		if("x".equals(buy)) {
			System.out.println("***입력 취소***");
			return;
		}
		System.out.println("판매가(x:취소):");
		double sell= sc.nextInt();
		if("x".equals(sell)) {
			System.out.println("***입력 취소***");
			return;
		}
		int newNameCode = getNameCode(inven);	//신제품 상위코드 생성
		newNameCode++;	//제품 코드 생성
		System.out.println("제품 코드:"+newNameCode);
		System.out.println("***신제품 등록 완료.***");
		
		inven.add(new Inven(typeCode, type, name, newNameCode, count, buy, sell));	
	}
	
	private int getNameCode(ArrayList<Inven> inven) {
		int lastNum = -1;
		int tempNum = -1;
		for(Integer i=0;i<inven.size();i++) {
			tempNum = inven.get(i).getNameCode();
			if(lastNum < tempNum) {
				lastNum = tempNum;
			}
		}
		return lastNum;
	}
}