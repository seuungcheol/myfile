package com.han.shop.proc;


import java.util.ArrayList;
import java.util.Scanner;

import com.han.shop.data.Member;

public class MenuMemberReg {
	
	public void proc(ArrayList<Member> members) {
		Scanner sc = new Scanner(System.in);
		System.out.println("***사원 등록***");
		String name;
		String tel;
		String sex;
		System.out.print("이름(x:취소):");
		name = sc.next();
		if("x".equals(name)) {
			System.out.println("**입력 취소**");
			return;
		}
		System.out.print("연락처(x:취소):");
		tel = sc.next();
		if("x".equals(tel)) {
			System.out.println("**입력 취소**");
			return;
		}
		System.out.print("성별(x:취소):");
		sex = sc.next();
		if("x".equals(sex)) {
			System.out.println("**입력 취소**");
			return;
		}
		int newNum = getLastNum(members);	//기존 사원 중 마지막 번호 찾기
		newNum++;	//사원번호 생성
		members.add(new Member(newNum, name,tel,sex));		
		System.out.println(name+"님 사원 번호 생성:"+newNum);
		System.out.println("***사원 추가 완료***");
	}
	private int getLastNum(ArrayList<Member> members) {
		int lastNum = -1;
		int tempNum = -1;
		for(int i=0;i<members.size();i++) {
			tempNum = members.get(i).getNum();
			if(lastNum < tempNum) {
				lastNum = tempNum;
			}
		}
		return lastNum;
		
	}
}
