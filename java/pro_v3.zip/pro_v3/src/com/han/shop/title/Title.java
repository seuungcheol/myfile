package com.han.shop.title;

import com.han.shop.Manager;

public class Title {
	public static final String TITLE = "***MyCom 사원 및 재고 관리 프로그램"+Manager.VERSION +"***";

}
